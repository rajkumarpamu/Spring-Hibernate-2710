package com.demo.aop;

public class TestController {
	
	
	public void validate(int age) {
		if (age > 18) {
			System.out.println("Eligible for Voting");

		} else {
			throw new ArithmeticException("Age Not valid");
		}
	}

}
