package com.demo.aop;

public class DemoController {

	public void  validate(int age) {
		if(age>18) {
			
			System.out.println("Passsed");
		}
		else {
			System.out.println("Failed");
		}
	}
}
