package com.demo.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class TrackDemoController {

	@Pointcut("execution(* DemoController.*(..))")
	public void m1() {
	}

	@After("m1()")
	public void myAdviceT(JoinPoint jp) {	
		System.out.println(jp.getSignature());
	}

}
