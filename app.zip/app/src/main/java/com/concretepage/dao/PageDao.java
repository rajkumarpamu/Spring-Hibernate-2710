package com.concretepage.dao;
public interface PageDao {
	public void persist();
}
 