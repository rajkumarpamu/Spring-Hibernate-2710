package com.demo.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {
	public static void main(String[] args) {

		// Step-1 create a Configuration Object
		// An instance of Configuration allows the application to specify properties and
		// mapping
		// documents to be used when creating a SessionFactory
		Configuration cfg = new Configuration();
		cfg.configure("hib.cfg.xml");

		// Step-2 - Create Session factory object
		// Instantiate a new SessionFactory, using the properties and mappings in this
		// configuration.
		SessionFactory sf = cfg.buildSessionFactory();

		// Create database connection and open a Session on it.
		// Step-3 - create Session Object
		Session session = sf.openSession();

		// Step-4 Begin the transaction
		Transaction tx = session.beginTransaction();

		Answer ans1=new Answer();  
	    ans1.setAnswername("Java is a programming language");  
	    ans1.setPostedBy("Ravi Malik");  
	      
	    Answer ans2=new Answer();  
	    ans2.setAnswername("Java is a platform");  
	    ans2.setPostedBy("Sudhir Kumar");  
	     
	    Question q1=new Question();  
	    q1.setQname("What is Java?");  
	    ArrayList<Answer> l1=new ArrayList<Answer>();  
	    l1.add(ans1);  
	    l1.add(ans2);  
	    q1.setAnswers(l1);  
	      
	    Answer ans3=new Answer();    
	    ans3.setAnswername("Servlet is an Interface");    
	    ans3.setPostedBy("Jai Kumar");    
	            
	    Answer ans4=new Answer();    
	    ans4.setAnswername("Servlet is an API");    
	    ans4.setPostedBy("Arun");    
	      
	    Question q2=new Question();  
	    q2.setQname("What is Servlet?");  
	    ArrayList<Answer> l2=new ArrayList<Answer>();  
	    l2.add(ans3);  
	    l2.add(ans4);  
	    q2.setAnswers(l2);  
	    session.persist(q1);    
	    session.persist(q2);    
		
		tx.commit();
		session.close();

	}

}
